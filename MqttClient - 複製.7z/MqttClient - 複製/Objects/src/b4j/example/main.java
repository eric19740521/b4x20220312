package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.MqttAsyncClientWrapper _mqtt = null;
public static String _user = "";
public static String _password = "";
public static String _mytopic = "";
public static anywheresoftware.b4a.randomaccessfile.B4XSerializator _serializator = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button1 = null;
public static anywheresoftware.b4j.objects.StatusBarWrapper _statusbar1 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _textarea1 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _txtmsg = null;
public static class _mymsg{
public boolean IsInitialized;
public String id;
public String msg;
public void Initialize() {
IsInitialized = true;
id = "";
msg = "";
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
String _clientid = "";
anywheresoftware.b4j.objects.MqttAsyncClientWrapper.MqttConnectOptionsWrapper _mo = null;
 //BA.debugLineNum = 25;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 26;BA.debugLine="Log(\"AppStart==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("765537","AppStart==>",0);
 //BA.debugLineNum = 28;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 29;BA.debugLine="MainForm.RootPane.LoadLayout(\"Layout1\")";
_mainform.getRootPane().LoadLayout(ba,"Layout1");
 //BA.debugLineNum = 30;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 32;BA.debugLine="Dim clientId As String = Rnd(0, 999999999) & Date";
_clientid = BA.NumberToString(anywheresoftware.b4a.keywords.Common.Rnd((int) (0),(int) (999999999)))+BA.NumberToString(anywheresoftware.b4a.keywords.Common.DateTime.getNow());
 //BA.debugLineNum = 33;BA.debugLine="mqtt.Initialize(\"mqtt\", \"tcp://192.168.1.162:5104";
_mqtt.Initialize(ba,"mqtt","tcp://192.168.1.162:51041",_clientid);
 //BA.debugLineNum = 35;BA.debugLine="Log(\"clientId= \" &clientId)";
anywheresoftware.b4a.keywords.Common.LogImpl("765546","clientId= "+_clientid,0);
 //BA.debugLineNum = 37;BA.debugLine="Dim mo As MqttConnectOptions";
_mo = new anywheresoftware.b4j.objects.MqttAsyncClientWrapper.MqttConnectOptionsWrapper();
 //BA.debugLineNum = 38;BA.debugLine="mo.Initialize(user, password)";
_mo.Initialize(_user,_password);
 //BA.debugLineNum = 39;BA.debugLine="mqtt.Connect2(mo)";
_mqtt.Connect2((org.eclipse.paho.client.mqttv3.MqttConnectOptions)(_mo.getObject()));
 //BA.debugLineNum = 42;BA.debugLine="StatusBar1.Initialize(\"StatusBar1\")";
_statusbar1.Initialize(ba,"StatusBar1");
 //BA.debugLineNum = 43;BA.debugLine="MainForm.RootPane.AddNode(StatusBar1, 0, 0, -1, 3";
_mainform.getRootPane().AddNode((javafx.scene.Node)(_statusbar1.getObject()),0,0,-1,30);
 //BA.debugLineNum = 44;BA.debugLine="MainForm.RootPane.SetAnchors(StatusBar1, 0, -1, 0";
_mainform.getRootPane().SetAnchors((javafx.scene.Node)(_statusbar1.getObject()),0,-1,0,0);
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return "";
}
public static String  _button1_click() throws Exception{
b4j.example.main._mymsg _a = null;
 //BA.debugLineNum = 53;BA.debugLine="Sub Button1_Click";
 //BA.debugLineNum = 60;BA.debugLine="Dim a As myMsg";
_a = new b4j.example.main._mymsg();
 //BA.debugLineNum = 61;BA.debugLine="a.Initialize";
_a.Initialize();
 //BA.debugLineNum = 62;BA.debugLine="a.id = mqtt.ClientId";
_a.id /*String*/  = _mqtt.getClientId();
 //BA.debugLineNum = 63;BA.debugLine="a.msg = txtMsg.Text";
_a.msg /*String*/  = _txtmsg.getText();
 //BA.debugLineNum = 65;BA.debugLine="serializator.ConvertObjectToBytes(a)";
_serializator.ConvertObjectToBytes((Object)(_a));
 //BA.debugLineNum = 67;BA.debugLine="mytopic = \"chat/\" & mqtt.ClientId";
_mytopic = "chat/"+_mqtt.getClientId();
 //BA.debugLineNum = 68;BA.debugLine="mqtt.Publish(mytopic, serializator.ConvertObjectT";
_mqtt.Publish(_mytopic,_serializator.ConvertObjectToBytes((Object)(_a)));
 //BA.debugLineNum = 69;BA.debugLine="TextArea1.Text = TextArea1.Text & Chr(13)&Chr(10)";
_textarea1.setText(_textarea1.getText()+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (13)))+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (10)))+"Me("+_mqtt.getClientId()+"):"+_a.msg /*String*/ );
 //BA.debugLineNum = 70;BA.debugLine="txtMsg.Text = \"\"";
_txtmsg.setText("");
 //BA.debugLineNum = 71;BA.debugLine="End Sub";
return "";
}
public static String  _mainform_closed() throws Exception{
 //BA.debugLineNum = 47;BA.debugLine="Sub MainForm_Closed";
 //BA.debugLineNum = 48;BA.debugLine="Log(\"MainForm_Closed==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("7131073","MainForm_Closed==>",0);
 //BA.debugLineNum = 50;BA.debugLine="mqtt.Close";
_mqtt.Close();
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return "";
}
public static String  _mqtt_connected(boolean _success) throws Exception{
 //BA.debugLineNum = 74;BA.debugLine="Sub mqtt_Connected (Success As Boolean)";
 //BA.debugLineNum = 75;BA.debugLine="Log(\"mqtt_Connected==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("7262145","mqtt_Connected==>",0);
 //BA.debugLineNum = 77;BA.debugLine="If Success = False Then";
if (_success==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 78;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("7262148",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(ba)),0);
 //BA.debugLineNum = 79;BA.debugLine="StatusBar1.Text = \"Error connecting\"";
_statusbar1.setText("Error connecting");
 }else {
 //BA.debugLineNum = 81;BA.debugLine="StatusBar1.Text = \"連線中\"";
_statusbar1.setText("連線中");
 //BA.debugLineNum = 82;BA.debugLine="mqtt.Subscribe(\"chat/#\", 2)	'『#』多層萬用字元";
_mqtt.Subscribe("chat/#",(int) (2));
 };
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
return "";
}
public static String  _mqtt_disconnected() throws Exception{
 //BA.debugLineNum = 91;BA.debugLine="Private Sub mqtt_Disconnected";
 //BA.debugLineNum = 92;BA.debugLine="Log(\"mqtt_Disconnected==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("7327681","mqtt_Disconnected==>",0);
 //BA.debugLineNum = 94;BA.debugLine="StatusBar1.Text = \"斷線中\"";
_statusbar1.setText("斷線中");
 //BA.debugLineNum = 96;BA.debugLine="End Sub";
return "";
}
public static String  _mqtt_messagearrived(String _topic,byte[] _payload) throws Exception{
b4j.example.main._mymsg _a = null;
 //BA.debugLineNum = 98;BA.debugLine="Private Sub mqtt_MessageArrived (Topic As String,";
 //BA.debugLineNum = 99;BA.debugLine="Log(\"mqtt_MessageArrived==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("7393217","mqtt_MessageArrived==>",0);
 //BA.debugLineNum = 100;BA.debugLine="Log(\"Topic= \"&Topic)";
anywheresoftware.b4a.keywords.Common.LogImpl("7393218","Topic= "+_topic,0);
 //BA.debugLineNum = 108;BA.debugLine="Dim a As myMsg";
_a = new b4j.example.main._mymsg();
 //BA.debugLineNum = 109;BA.debugLine="a.Initialize";
_a.Initialize();
 //BA.debugLineNum = 111;BA.debugLine="a = serializator.ConvertBytesToObject(Payload)";
_a = (b4j.example.main._mymsg)(_serializator.ConvertBytesToObject(_payload));
 //BA.debugLineNum = 113;BA.debugLine="If a.id == mqtt.ClientId Then";
if ((_a.id /*String*/ ).equals(_mqtt.getClientId())) { 
 //BA.debugLineNum = 114;BA.debugLine="Log(\"自己的訊息不用顯示!!\")";
anywheresoftware.b4a.keywords.Common.LogImpl("7393232","自己的訊息不用顯示!!",0);
 }else {
 //BA.debugLineNum = 116;BA.debugLine="TextArea1.Text = TextArea1.Text & Chr(13)&Chr(10";
_textarea1.setText(_textarea1.getText()+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (13)))+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (10)))+"You("+_mqtt.getClientId()+"):"+_a.msg /*String*/ );
 };
 //BA.debugLineNum = 123;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private mqtt As MqttClient";
_mqtt = new anywheresoftware.b4j.objects.MqttAsyncClientWrapper();
 //BA.debugLineNum = 8;BA.debugLine="Private user As String = \"\"";
_user = "";
 //BA.debugLineNum = 9;BA.debugLine="Private password As String = \"\"";
_password = "";
 //BA.debugLineNum = 10;BA.debugLine="Private mytopic As String";
_mytopic = "";
 //BA.debugLineNum = 12;BA.debugLine="Private serializator As B4XSerializator";
_serializator = new anywheresoftware.b4a.randomaccessfile.B4XSerializator();
 //BA.debugLineNum = 13;BA.debugLine="Type myMsg(id As String,msg As String)";
;
 //BA.debugLineNum = 15;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 16;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 17;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 18;BA.debugLine="Private Button1 As B4XView";
_button1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Private StatusBar1 As StatusBar";
_statusbar1 = new anywheresoftware.b4j.objects.StatusBarWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Private TextArea1 As B4XView";
_textarea1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Private txtMsg As B4XView";
_txtmsg = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return "";
}
}
