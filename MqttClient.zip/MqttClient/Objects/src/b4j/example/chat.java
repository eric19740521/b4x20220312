package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class chat extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.chat", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.chat.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4j.example.b4xfloattextfield _textfield = null;
public b4j.example.customlistview _clv = null;
public b4j.example.bbcodeview _bbcodeview1 = null;
public b4j.example.bctextengine _engine = null;
public b4j.example.bitmapcreator _bc = null;
public int _arrowwidth = 0;
public int _gap = 0;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlbottom = null;
public boolean _lastuserleft = false;
public b4j.example.dateutils _dateutils = null;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.httputils2service _httputils2service = null;
public b4j.example.b4xcollections _b4xcollections = null;
public b4j.example.xuiviewsutils _xuiviewsutils = null;
public String  _additem(String _text,boolean _right) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
String _user = "";
anywheresoftware.b4a.objects.B4XViewWrapper _ivtext = null;
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _bmptext = null;
int _textwidth = 0;
int _textheight = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _ivbg = null;
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _bmpbg = null;
 //BA.debugLineNum = 56;BA.debugLine="Private Sub AddItem (Text As String, Right As Bool";
 //BA.debugLineNum = 57;BA.debugLine="Dim p As B4XView = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 58;BA.debugLine="p.Color = xui.Color_Transparent";
_p.setColor(_xui.Color_Transparent);
 //BA.debugLineNum = 59;BA.debugLine="Dim User As String";
_user = "";
 //BA.debugLineNum = 61;BA.debugLine="If Right Then User = \"是我!!\" Else User = \"路人甲?!\"";
if (_right) { 
_user = "是我!!";}
else {
_user = "路人甲?!";};
 //BA.debugLineNum = 63;BA.debugLine="BBCodeView1.ExternalRuns = BuildMessage(Text, Use";
_bbcodeview1._externalruns /*anywheresoftware.b4a.objects.collections.List*/  = _buildmessage(_text,_user);
 //BA.debugLineNum = 64;BA.debugLine="BBCodeView1.ParseAndDraw";
_bbcodeview1._parseanddraw /*String*/ ();
 //BA.debugLineNum = 65;BA.debugLine="Dim ivText As B4XView = CreateImageView";
_ivtext = new anywheresoftware.b4a.objects.B4XViewWrapper();
_ivtext = _createimageview();
 //BA.debugLineNum = 67;BA.debugLine="Dim bmpText As B4XBitmap = GetBitmap(BBCodeView1.";
_bmptext = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_bmptext = _getbitmap((anywheresoftware.b4j.objects.ImageViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.ImageViewWrapper(), (javafx.scene.image.ImageView)(_bbcodeview1._foregroundimageview /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getObject())));
 //BA.debugLineNum = 69;BA.debugLine="Dim TextWidth As Int = bmpText.Width / Engine.mSc";
_textwidth = (int) (_bmptext.getWidth()/(double)_engine._mscale /*float*/ );
 //BA.debugLineNum = 70;BA.debugLine="Dim TextHeight As Int = bmpText.Height / Engine.m";
_textheight = (int) (_bmptext.getHeight()/(double)_engine._mscale /*float*/ );
 //BA.debugLineNum = 72;BA.debugLine="bc.SetBitmapToImageView(bmpText, ivText)";
_bc._setbitmaptoimageview(_bmptext,_ivtext);
 //BA.debugLineNum = 73;BA.debugLine="Dim ivBG As B4XView = CreateImageView";
_ivbg = new anywheresoftware.b4a.objects.B4XViewWrapper();
_ivbg = _createimageview();
 //BA.debugLineNum = 75;BA.debugLine="Dim bmpBG As B4XBitmap = DrawBubble(TextWidth, Te";
_bmpbg = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_bmpbg = _drawbubble(_textwidth,_textheight,_right);
 //BA.debugLineNum = 76;BA.debugLine="bc.SetBitmapToImageView(bmpBG, ivBG)";
_bc._setbitmaptoimageview(_bmpbg,_ivbg);
 //BA.debugLineNum = 77;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, CLV.sv.ScrollViewCon";
_p.SetLayoutAnimated((int) (0),0,0,_clv._sv.getScrollViewContentWidth()-__c.DipToCurrent((int) (2)),_textheight+3*_gap);
 //BA.debugLineNum = 78;BA.debugLine="If Right Then";
if (_right) { 
 //BA.debugLineNum = 79;BA.debugLine="p.AddView(ivBG, p.Width - bmpBG.Width * xui.Scal";
_p.AddView((javafx.scene.Node)(_ivbg.getObject()),_p.getWidth()-_bmpbg.getWidth()*_xui.getScale(),_gap,_bmpbg.getWidth()*_xui.getScale(),_bmpbg.getHeight()*_xui.getScale());
 //BA.debugLineNum = 80;BA.debugLine="p.AddView(ivText, p.Width - Gap - ArrowWidth - T";
_p.AddView((javafx.scene.Node)(_ivtext.getObject()),_p.getWidth()-_gap-_arrowwidth-_textwidth,2*_gap,_textwidth,_textheight);
 }else {
 //BA.debugLineNum = 82;BA.debugLine="p.AddView(ivBG, 0, Gap, bmpBG.Width * xui.Scale,";
_p.AddView((javafx.scene.Node)(_ivbg.getObject()),0,_gap,_bmpbg.getWidth()*_xui.getScale(),_bmpbg.getHeight()*_xui.getScale());
 //BA.debugLineNum = 83;BA.debugLine="p.AddView(ivText, Gap + ArrowWidth, 2 * Gap, Tex";
_p.AddView((javafx.scene.Node)(_ivtext.getObject()),_gap+_arrowwidth,2*_gap,_textwidth,_textheight);
 };
 //BA.debugLineNum = 85;BA.debugLine="CLV.Add(p, Null)";
_clv._add(_p,__c.Null);
 //BA.debugLineNum = 86;BA.debugLine="ScrollToLastItem";
_scrolltolastitem();
 //BA.debugLineNum = 87;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.collections.List  _buildmessage(String _text,String _user) throws Exception{
b4j.example.bctextengine._bctextrun _title = null;
b4j.example.bctextengine._bctextrun _textrun = null;
b4j.example.bctextengine._bctextrun _time = null;
 //BA.debugLineNum = 134;BA.debugLine="Private Sub BuildMessage (Text As String, User As";
 //BA.debugLineNum = 135;BA.debugLine="Dim title As BCTextRun = Engine.CreateRun(User &";
_title = _engine._createrun /*b4j.example.bctextengine._bctextrun*/ (_user+__c.CRLF);
 //BA.debugLineNum = 136;BA.debugLine="title.TextFont  = BBCodeView1.ParseData.DefaultBo";
_title.TextFont /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont*/  = _bbcodeview1._parsedata /*b4j.example.bbcodeparser._bbcodeparsedata*/ .DefaultBoldFont /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont*/ ;
 //BA.debugLineNum = 137;BA.debugLine="Dim TextRun As BCTextRun = Engine.CreateRun(Text";
_textrun = _engine._createrun /*b4j.example.bctextengine._bctextrun*/ (_text+__c.CRLF);
 //BA.debugLineNum = 138;BA.debugLine="Dim time As BCTextRun = Engine.CreateRun(DateTime";
_time = _engine._createrun /*b4j.example.bctextengine._bctextrun*/ (__c.DateTime.Time(__c.DateTime.getNow()));
 //BA.debugLineNum = 139;BA.debugLine="time.TextFont = xui.CreateDefaultFont(10)";
_time.TextFont /*anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont*/  = _xui.CreateDefaultFont((float) (10));
 //BA.debugLineNum = 140;BA.debugLine="time.TextColor = xui.Color_Gray";
_time.TextColor /*int*/  = _xui.Color_Gray;
 //BA.debugLineNum = 141;BA.debugLine="Return Array(title, TextRun, time)";
if (true) return anywheresoftware.b4a.keywords.Common.ArrayToList(new Object[]{(Object)(_title),(Object)(_textrun),(Object)(_time)});
 //BA.debugLineNum = 142;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 4;BA.debugLine="Private TextField As B4XFloatTextField";
_textfield = new b4j.example.b4xfloattextfield();
 //BA.debugLineNum = 5;BA.debugLine="Private CLV As CustomListView";
_clv = new b4j.example.customlistview();
 //BA.debugLineNum = 6;BA.debugLine="Private BBCodeView1 As BBCodeView";
_bbcodeview1 = new b4j.example.bbcodeview();
 //BA.debugLineNum = 7;BA.debugLine="Private Engine As BCTextEngine";
_engine = new b4j.example.bctextengine();
 //BA.debugLineNum = 8;BA.debugLine="Private bc As BitmapCreator";
_bc = new b4j.example.bitmapcreator();
 //BA.debugLineNum = 9;BA.debugLine="Private ArrowWidth As Int = 10dip";
_arrowwidth = __c.DipToCurrent((int) (10));
 //BA.debugLineNum = 10;BA.debugLine="Private Gap As Int = 6dip";
_gap = __c.DipToCurrent((int) (6));
 //BA.debugLineNum = 11;BA.debugLine="Private pnlBottom As B4XView";
_pnlbottom = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Private LastUserLeft As Boolean = True";
_lastuserleft = __c.True;
 //BA.debugLineNum = 13;BA.debugLine="End Sub";
return "";
}
public String  _clv_itemclick(int _index,Object _value) throws Exception{
 //BA.debugLineNum = 152;BA.debugLine="Private Sub CLV_ItemClick (Index As Int, Value As";
 //BA.debugLineNum = 157;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.B4XViewWrapper  _createimageview() throws Exception{
anywheresoftware.b4j.objects.ImageViewWrapper _iv = null;
 //BA.debugLineNum = 159;BA.debugLine="Private Sub CreateImageView As B4XView";
 //BA.debugLineNum = 160;BA.debugLine="Dim iv As ImageView";
_iv = new anywheresoftware.b4j.objects.ImageViewWrapper();
 //BA.debugLineNum = 161;BA.debugLine="iv.Initialize(\"\")";
_iv.Initialize(ba,"");
 //BA.debugLineNum = 162;BA.debugLine="Return iv";
if (true) return (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_iv.getObject()));
 //BA.debugLineNum = 163;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper  _drawbubble(int _width,int _height,boolean _right) throws Exception{
int _scaledgap = 0;
int _scaledarrowwidth = 0;
int _nw = 0;
int _nh = 0;
anywheresoftware.b4a.objects.B4XCanvas.B4XRect _r = null;
b4j.example.bcpath _path = null;
int _clr = 0;
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _b = null;
 //BA.debugLineNum = 98;BA.debugLine="Private Sub DrawBubble (Width As Int, Height As In";
 //BA.debugLineNum = 100;BA.debugLine="Width = Ceil(Width / xui.Scale)";
_width = (int) (__c.Ceil(_width/(double)_xui.getScale()));
 //BA.debugLineNum = 101;BA.debugLine="Height = Ceil(Height / xui.Scale)";
_height = (int) (__c.Ceil(_height/(double)_xui.getScale()));
 //BA.debugLineNum = 102;BA.debugLine="Dim ScaledGap As Int = Ceil(Gap / xui.Scale)";
_scaledgap = (int) (__c.Ceil(_gap/(double)_xui.getScale()));
 //BA.debugLineNum = 103;BA.debugLine="Dim ScaledArrowWidth As Int = Ceil(ArrowWidth / x";
_scaledarrowwidth = (int) (__c.Ceil(_arrowwidth/(double)_xui.getScale()));
 //BA.debugLineNum = 104;BA.debugLine="Dim nw As Int = Width + 2 * ScaledGap + ScaledArr";
_nw = (int) (_width+2*_scaledgap+_scaledarrowwidth);
 //BA.debugLineNum = 105;BA.debugLine="Dim nh As Int = Height + 2 * ScaledGap";
_nh = (int) (_height+2*_scaledgap);
 //BA.debugLineNum = 106;BA.debugLine="If bc.mWidth < nw Or bc.mHeight < nh Then";
if (_bc._mwidth<_nw || _bc._mheight<_nh) { 
 //BA.debugLineNum = 107;BA.debugLine="bc.Initialize(Max(bc.mWidth, nw), Max(bc.mHeight";
_bc._initialize(ba,(int) (__c.Max(_bc._mwidth,_nw)),(int) (__c.Max(_bc._mheight,_nh)));
 };
 //BA.debugLineNum = 109;BA.debugLine="bc.DrawRect(bc.TargetRect, xui.Color_Transparent,";
_bc._drawrect(_bc._targetrect,_xui.Color_Transparent,__c.True,(int) (0));
 //BA.debugLineNum = 110;BA.debugLine="Dim r As B4XRect";
_r = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
 //BA.debugLineNum = 111;BA.debugLine="Dim path As BCPath";
_path = new b4j.example.bcpath();
 //BA.debugLineNum = 112;BA.debugLine="Dim clr As Int";
_clr = 0;
 //BA.debugLineNum = 113;BA.debugLine="If Right Then clr = 0xFFEFEFEF Else clr = 0xFFC1F";
if (_right) { 
_clr = ((int)0xffefefef);}
else {
_clr = ((int)0xffc1f7a3);};
 //BA.debugLineNum = 114;BA.debugLine="If Right Then";
if (_right) { 
 //BA.debugLineNum = 115;BA.debugLine="r.Initialize(0, 0, nw - ScaledArrowWidth, nh)";
_r.Initialize((float) (0),(float) (0),(float) (_nw-_scaledarrowwidth),(float) (_nh));
 //BA.debugLineNum = 116;BA.debugLine="path.Initialize(nw - 1, 1)";
_path._initialize(ba,(float) (_nw-1),(float) (1));
 //BA.debugLineNum = 117;BA.debugLine="path.LineTo(nw - 1 - (10 + ScaledArrowWidth), 1)";
_path._lineto((float) (_nw-1-(10+_scaledarrowwidth)),(float) (1));
 //BA.debugLineNum = 118;BA.debugLine="path.LineTo(nw - 1 - ScaledArrowWidth, 10)";
_path._lineto((float) (_nw-1-_scaledarrowwidth),(float) (10));
 //BA.debugLineNum = 119;BA.debugLine="path.LineTo(nw - 1, 1)";
_path._lineto((float) (_nw-1),(float) (1));
 }else {
 //BA.debugLineNum = 121;BA.debugLine="r.Initialize(ScaledArrowWidth, 1, nw, nh)";
_r.Initialize((float) (_scaledarrowwidth),(float) (1),(float) (_nw),(float) (_nh));
 //BA.debugLineNum = 122;BA.debugLine="path.Initialize(1, 1)";
_path._initialize(ba,(float) (1),(float) (1));
 //BA.debugLineNum = 123;BA.debugLine="path.LineTo((10 + ScaledArrowWidth), 1)";
_path._lineto((float) ((10+_scaledarrowwidth)),(float) (1));
 //BA.debugLineNum = 124;BA.debugLine="path.LineTo(ScaledArrowWidth, 10)";
_path._lineto((float) (_scaledarrowwidth),(float) (10));
 //BA.debugLineNum = 125;BA.debugLine="path.LineTo(1, 1)";
_path._lineto((float) (1),(float) (1));
 };
 //BA.debugLineNum = 127;BA.debugLine="bc.DrawRectRounded(r, clr, True, 0, 10)";
_bc._drawrectrounded(_r,_clr,__c.True,(int) (0),(int) (10));
 //BA.debugLineNum = 128;BA.debugLine="bc.DrawPath(path, clr, True, 0)";
_bc._drawpath(_path,_clr,__c.True,(int) (0));
 //BA.debugLineNum = 129;BA.debugLine="bc.DrawPath(path, clr, False, 2)";
_bc._drawpath(_path,_clr,__c.False,(int) (2));
 //BA.debugLineNum = 130;BA.debugLine="Dim b As B4XBitmap = bc.Bitmap";
_b = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_b = _bc._getbitmap();
 //BA.debugLineNum = 131;BA.debugLine="Return b.Crop(0, 1, nw, nh)";
if (true) return _b.Crop((int) (0),(int) (1),_nw,_nh);
 //BA.debugLineNum = 132;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper  _getbitmap(anywheresoftware.b4j.objects.ImageViewWrapper _iv) throws Exception{
 //BA.debugLineNum = 144;BA.debugLine="Private Sub GetBitmap (iv As ImageView) As B4XBitm";
 //BA.debugLineNum = 146;BA.debugLine="Return iv.GetImage";
if (true) return (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (javafx.scene.image.Image)(_iv.GetImage().getObject()));
 //BA.debugLineNum = 150;BA.debugLine="End Sub";
return null;
}
public String  _heightchanged(int _newheight) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _c = null;
 //BA.debugLineNum = 48;BA.debugLine="Public Sub HeightChanged (NewHeight As Int)";
 //BA.debugLineNum = 49;BA.debugLine="Dim c As B4XView = CLV.AsView";
_c = new anywheresoftware.b4a.objects.B4XViewWrapper();
_c = _clv._asview();
 //BA.debugLineNum = 50;BA.debugLine="c.Height = NewHeight - pnlBottom.Height";
_c.setHeight(_newheight-_pnlbottom.getHeight());
 //BA.debugLineNum = 51;BA.debugLine="CLV.Base_Resize(c.Width, c.Height)";
_clv._base_resize(_c.getWidth(),_c.getHeight());
 //BA.debugLineNum = 52;BA.debugLine="pnlBottom.Top = NewHeight - pnlBottom.Height";
_pnlbottom.setTop(_newheight-_pnlbottom.getHeight());
 //BA.debugLineNum = 53;BA.debugLine="ScrollToLastItem";
_scrolltolastitem();
 //BA.debugLineNum = 54;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper _parent) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 15;BA.debugLine="Public Sub Initialize (Parent As B4XView)";
 //BA.debugLineNum = 16;BA.debugLine="Parent.LoadLayout(\"Layout1\")";
_parent.LoadLayout("Layout1",ba);
 //BA.debugLineNum = 17;BA.debugLine="Engine.Initialize(Parent)";
_engine._initialize /*String*/ (ba,_parent);
 //BA.debugLineNum = 18;BA.debugLine="bc.Initialize(300, 300)";
_bc._initialize(ba,(int) (300),(int) (300));
 //BA.debugLineNum = 19;BA.debugLine="TextField.NextField = TextField";
_textfield._setnextfield /*b4j.example.b4xfloattextfield*/ (_textfield);
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public String  _lblsend_click() throws Exception{
anywheresoftware.b4j.objects.TextInputControlWrapper.TextAreaWrapper _ta = null;
 //BA.debugLineNum = 22;BA.debugLine="Private Sub lblSend_Click";
 //BA.debugLineNum = 23;BA.debugLine="If TextField.Text.Length > 0 Then";
if (_textfield._gettext /*String*/ ().length()>0) { 
 //BA.debugLineNum = 27;BA.debugLine="AddItem(TextField.Text, True)";
_additem(_textfield._gettext /*String*/ (),__c.True);
 //BA.debugLineNum = 29;BA.debugLine="CallSub2(Main ,\"mqttSend\", TextField.Text)";
__c.CallSubNew2(ba,(Object)(_main.getObject()),"mqttSend",(Object)(_textfield._gettext /*String*/ ()));
 };
 //BA.debugLineNum = 31;BA.debugLine="TextField.RequestFocusAndShowKeyboard";
_textfield._requestfocusandshowkeyboard /*String*/ ();
 //BA.debugLineNum = 33;BA.debugLine="Dim ta As TextArea = TextField.TextField";
_ta = new anywheresoftware.b4j.objects.TextInputControlWrapper.TextAreaWrapper();
_ta = (anywheresoftware.b4j.objects.TextInputControlWrapper.TextAreaWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.TextInputControlWrapper.TextAreaWrapper(), (javafx.scene.control.TextArea)(_textfield._gettextfield /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().getObject()));
 //BA.debugLineNum = 34;BA.debugLine="ta.SelectAll";
_ta.SelectAll();
 //BA.debugLineNum = 43;BA.debugLine="TextField.Text = \"\"";
_textfield._settext /*String*/ ("");
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return "";
}
public String  _lblsend_mouseclicked(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
 //BA.debugLineNum = 166;BA.debugLine="Sub lblSend_MouseClicked (EventData As MouseEvent)";
 //BA.debugLineNum = 167;BA.debugLine="lblSend_Click";
_lblsend_click();
 //BA.debugLineNum = 168;BA.debugLine="EventData.Consume";
_eventdata.Consume();
 //BA.debugLineNum = 169;BA.debugLine="End Sub";
return "";
}
public void  _scrolltolastitem() throws Exception{
ResumableSub_ScrollToLastItem rsub = new ResumableSub_ScrollToLastItem(this);
rsub.resume(ba, null);
}
public static class ResumableSub_ScrollToLastItem extends BA.ResumableSub {
public ResumableSub_ScrollToLastItem(b4j.example.chat parent) {
this.parent = parent;
}
b4j.example.chat parent;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 90;BA.debugLine="Sleep(50)";
parent.__c.Sleep(ba,this,(int) (50));
this.state = 9;
return;
case 9:
//C
this.state = 1;
;
 //BA.debugLineNum = 91;BA.debugLine="If CLV.Size > 0 Then";
if (true) break;

case 1:
//if
this.state = 8;
if (parent._clv._getsize()>0) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 92;BA.debugLine="If CLV.sv.ScrollViewContentHeight > CLV.sv.Heigh";
if (true) break;

case 4:
//if
this.state = 7;
if (parent._clv._sv.getScrollViewContentHeight()>parent._clv._sv.getHeight()) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 93;BA.debugLine="CLV.ScrollToItem(CLV.Size - 1)";
parent._clv._scrolltoitem((int) (parent._clv._getsize()-1));
 if (true) break;

case 7:
//C
this.state = 8;
;
 if (true) break;

case 8:
//C
this.state = -1;
;
 //BA.debugLineNum = 96;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "ADDITEM"))
	return _additem((String) args[0], (Boolean) args[1]);
return BA.SubDelegator.SubNotFound;
}
}
