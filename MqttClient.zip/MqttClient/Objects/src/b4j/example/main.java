package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.MqttAsyncClientWrapper _mqtt = null;
public static String _user = "";
public static String _password = "";
public static String _mytopic = "";
public static anywheresoftware.b4a.randomaccessfile.B4XSerializator _serializator = null;
public static b4j.example.chat _chat1 = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static b4j.example.dateutils _dateutils = null;
public static b4j.example.cssutils _cssutils = null;
public static b4j.example.httputils2service _httputils2service = null;
public static b4j.example.b4xcollections _b4xcollections = null;
public static b4j.example.xuiviewsutils _xuiviewsutils = null;
public static class _mymsg{
public boolean IsInitialized;
public String id;
public String msg;
public void Initialize() {
IsInitialized = true;
id = "";
msg = "";
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
String _clientid = "";
anywheresoftware.b4j.objects.MqttAsyncClientWrapper.MqttConnectOptionsWrapper _mo = null;
 //BA.debugLineNum = 27;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 28;BA.debugLine="Log(\"AppStart==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("265537","AppStart==>",0);
 //BA.debugLineNum = 30;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 31;BA.debugLine="MainForm.Stylesheets.Add(File.GetUri(File.DirAsse";
_mainform.getStylesheets().Add((Object)(anywheresoftware.b4a.keywords.Common.File.GetUri(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"Dialog.css")));
 //BA.debugLineNum = 33;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 34;BA.debugLine="MainForm.Resizable = False";
_mainform.setResizable(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 35;BA.debugLine="chat1.Initialize(MainForm.RootPane)";
_chat1._initialize /*String*/ (ba,(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_mainform.getRootPane().getObject())));
 //BA.debugLineNum = 38;BA.debugLine="Dim clientId As String = Rnd(0, 999999999) & Date";
_clientid = BA.NumberToString(anywheresoftware.b4a.keywords.Common.Rnd((int) (0),(int) (999999999)))+BA.NumberToString(anywheresoftware.b4a.keywords.Common.DateTime.getNow());
 //BA.debugLineNum = 39;BA.debugLine="mqtt.Initialize(\"mqtt\", \"tcp://192.168.1.162:5104";
_mqtt.Initialize(ba,"mqtt","tcp://192.168.1.162:51041",_clientid);
 //BA.debugLineNum = 41;BA.debugLine="Log(\"clientId= \" &clientId)";
anywheresoftware.b4a.keywords.Common.LogImpl("265550","clientId= "+_clientid,0);
 //BA.debugLineNum = 43;BA.debugLine="Dim mo As MqttConnectOptions";
_mo = new anywheresoftware.b4j.objects.MqttAsyncClientWrapper.MqttConnectOptionsWrapper();
 //BA.debugLineNum = 44;BA.debugLine="mo.Initialize(user, password)";
_mo.Initialize(_user,_password);
 //BA.debugLineNum = 45;BA.debugLine="mqtt.Connect2(mo)";
_mqtt.Connect2((org.eclipse.paho.client.mqttv3.MqttConnectOptions)(_mo.getObject()));
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return "";
}
public static String  _mainform_closed() throws Exception{
 //BA.debugLineNum = 53;BA.debugLine="Sub MainForm_Closed";
 //BA.debugLineNum = 54;BA.debugLine="Log(\"MainForm_Closed==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("2196609","MainForm_Closed==>",0);
 //BA.debugLineNum = 56;BA.debugLine="mqtt.Close";
_mqtt.Close();
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return "";
}
public static String  _mqtt_connected(boolean _success) throws Exception{
 //BA.debugLineNum = 96;BA.debugLine="Sub mqtt_Connected (Success As Boolean)";
 //BA.debugLineNum = 97;BA.debugLine="Log(\"mqtt_Connected==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("2262145","mqtt_Connected==>",0);
 //BA.debugLineNum = 99;BA.debugLine="If Success = False Then";
if (_success==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 100;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("2262148",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(ba)),0);
 //BA.debugLineNum = 102;BA.debugLine="MainForm.Title = \"簡易聊天室-\" & \"Error connecting\"";
_mainform.setTitle("簡易聊天室-"+"Error connecting");
 }else {
 //BA.debugLineNum = 105;BA.debugLine="MainForm.Title = \"簡易聊天室-\" & \"連線中\"";
_mainform.setTitle("簡易聊天室-"+"連線中");
 //BA.debugLineNum = 107;BA.debugLine="mqtt.Subscribe(\"chat/#\", 2)	'『#』多層萬用字元";
_mqtt.Subscribe("chat/#",(int) (2));
 };
 //BA.debugLineNum = 114;BA.debugLine="End Sub";
return "";
}
public static String  _mqtt_disconnected() throws Exception{
 //BA.debugLineNum = 116;BA.debugLine="Private Sub mqtt_Disconnected";
 //BA.debugLineNum = 117;BA.debugLine="Log(\"mqtt_Disconnected==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("2327681","mqtt_Disconnected==>",0);
 //BA.debugLineNum = 119;BA.debugLine="MainForm.Title = \"簡易聊天室-\" & \"斷線中\"";
_mainform.setTitle("簡易聊天室-"+"斷線中");
 //BA.debugLineNum = 122;BA.debugLine="End Sub";
return "";
}
public static String  _mqtt_messagearrived(String _topic,byte[] _payload) throws Exception{
b4j.example.main._mymsg _a = null;
 //BA.debugLineNum = 124;BA.debugLine="Private Sub mqtt_MessageArrived (Topic As String,";
 //BA.debugLineNum = 125;BA.debugLine="Log(\"mqtt_MessageArrived==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("2393217","mqtt_MessageArrived==>",0);
 //BA.debugLineNum = 126;BA.debugLine="Log(\"Topic= \"&Topic)";
anywheresoftware.b4a.keywords.Common.LogImpl("2393218","Topic= "+_topic,0);
 //BA.debugLineNum = 134;BA.debugLine="Dim a As myMsg";
_a = new b4j.example.main._mymsg();
 //BA.debugLineNum = 135;BA.debugLine="a.Initialize";
_a.Initialize();
 //BA.debugLineNum = 137;BA.debugLine="a = serializator.ConvertBytesToObject(Payload)";
_a = (b4j.example.main._mymsg)(_serializator.ConvertBytesToObject(_payload));
 //BA.debugLineNum = 139;BA.debugLine="If a.id == mqtt.ClientId Then";
if ((_a.id /*String*/ ).equals(_mqtt.getClientId())) { 
 //BA.debugLineNum = 140;BA.debugLine="Log(\"自己的訊息不用顯示!!\")";
anywheresoftware.b4a.keywords.Common.LogImpl("2393232","自己的訊息不用顯示!!",0);
 }else {
 //BA.debugLineNum = 144;BA.debugLine="CallSub3(chat1,\"AddItem\",a.msg,False)";
anywheresoftware.b4a.keywords.Common.CallSubNew3(ba,(Object)(_chat1),"AddItem",(Object)(_a.msg /*String*/ ),(Object)(anywheresoftware.b4a.keywords.Common.False));
 };
 //BA.debugLineNum = 151;BA.debugLine="End Sub";
return "";
}
public static String  _mqttsend(String _s1) throws Exception{
b4j.example.main._mymsg _a = null;
 //BA.debugLineNum = 59;BA.debugLine="Sub mqttSend(s1 As String)";
 //BA.debugLineNum = 61;BA.debugLine="Dim a As myMsg";
_a = new b4j.example.main._mymsg();
 //BA.debugLineNum = 62;BA.debugLine="a.Initialize";
_a.Initialize();
 //BA.debugLineNum = 63;BA.debugLine="a.id = mqtt.ClientId";
_a.id /*String*/  = _mqtt.getClientId();
 //BA.debugLineNum = 64;BA.debugLine="a.msg = s1";
_a.msg /*String*/  = _s1;
 //BA.debugLineNum = 66;BA.debugLine="serializator.ConvertObjectToBytes(a)";
_serializator.ConvertObjectToBytes((Object)(_a));
 //BA.debugLineNum = 68;BA.debugLine="mytopic = \"chat/\" & mqtt.ClientId";
_mytopic = "chat/"+_mqtt.getClientId();
 //BA.debugLineNum = 69;BA.debugLine="mqtt.Publish(mytopic, serializator.ConvertObjectT";
_mqtt.Publish(_mytopic,_serializator.ConvertObjectToBytes((Object)(_a)));
 //BA.debugLineNum = 72;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        b4j.example.dateutils._process_globals();
b4j.example.cssutils._process_globals();
main._process_globals();
httputils2service._process_globals();
b4xcollections._process_globals();
xuiviewsutils._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private mqtt As MqttClient";
_mqtt = new anywheresoftware.b4j.objects.MqttAsyncClientWrapper();
 //BA.debugLineNum = 8;BA.debugLine="Private user As String = \"\"";
_user = "";
 //BA.debugLineNum = 9;BA.debugLine="Private password As String = \"\"";
_password = "";
 //BA.debugLineNum = 10;BA.debugLine="Private mytopic As String";
_mytopic = "";
 //BA.debugLineNum = 12;BA.debugLine="Private serializator As B4XSerializator";
_serializator = new anywheresoftware.b4a.randomaccessfile.B4XSerializator();
 //BA.debugLineNum = 13;BA.debugLine="Type myMsg(id As String,msg As String)";
;
 //BA.debugLineNum = 15;BA.debugLine="Private chat1 As Chat";
_chat1 = new b4j.example.chat();
 //BA.debugLineNum = 17;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 18;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 19;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return "";
}
}
